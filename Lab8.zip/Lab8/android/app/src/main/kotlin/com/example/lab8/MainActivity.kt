package com.example.lab8

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
