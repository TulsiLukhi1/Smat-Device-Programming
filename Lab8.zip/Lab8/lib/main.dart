import 'package:flutter/material.dart';
import 'package:lab8/code1.dart';
import 'package:lab8/code2.dart';
import 'package:lab8/code3.dart';
import 'package:lab8/code4.dart';
import 'package:lab8/code5.dart';
import 'package:lab8/code6.dart';

void main() {
  runApp(MaterialApp(
    routes: {
      //'/': (context) => FirstClass(),
      //'/': (context) => SecondClass(),
      //'/': (context) => ThirdClass(),
      //'/': (context) => FourthClass(),
      //'/': (context) => FifthClass(),
      '/': (context) => SixthClass(),
    },
  ));
}
